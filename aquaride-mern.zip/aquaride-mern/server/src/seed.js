import 'dotenv/config';
import Ferry from './models/Ferry.js';
import Route from './models/Route.js';
import ActiveFerry from './models/ActiveFerry.js';

const blocked = ['A1', 'A2', 'B3', 'C4', 'D2', 'E1', 'E4', 'F3'];
const ferries = [
  { name: 'Makruzz Gold', operator: 'Makruzz', from: 'Port Blair', to: 'Havelock', departure: '08:15 AM', arrival: '10:30 AM', duration: '2h 15m', price: 1850, rating: 4.8, reviews: 1250, seatsLeft: 24, premium: true, amenities: ['AC', 'WiFi', 'Refreshments', 'Entertainment', 'Life Jackets'] },
  { name: 'Mumbai Elite', operator: 'Mumbai Ferries', from: 'Mumbai', to: 'Mandwa', departure: '02:00 PM', arrival: '03:30 PM', duration: '1h 30m', price: 520, rating: 4.7, reviews: 892, seatsLeft: 32, premium: true, amenities: ['AC', 'WiFi', 'Refreshments', 'Entertainment', 'Life Jackets'] },
  { name: 'Sea Link Premium', operator: 'Sea Link', from: 'Mumbai', to: 'Alibaug', departure: '08:00 AM', arrival: '09:00 AM', duration: '1h 00m', price: 450, rating: 4.6, reviews: 640, seatsLeft: 18, premium: true, amenities: ['AC', 'WiFi', 'Life Jackets'] },
  { name: 'Green Ocean', operator: 'Nautika', from: 'Havelock', to: 'Neil Island', departure: '11:00 AM', arrival: '11:45 AM', duration: '45m', price: 1100, rating: 4.5, reviews: 410, seatsLeft: 26, premium: false, amenities: ['AC', 'Refreshments', 'Life Jackets'] },
  { name: 'Goa Cruiser', operator: 'Goa Ferries', from: 'Goa (Panaji)', to: 'Divar Island', departure: '09:30 AM', arrival: '09:50 AM', duration: '20m', price: 60, rating: 4.2, reviews: 300, seatsLeft: 30, premium: false, amenities: ['Life Jackets'] },
  { name: 'Kochi Backwater', operator: 'KSWTD', from: 'Kochi', to: 'Vypeen', departure: '07:30 AM', arrival: '07:50 AM', duration: '20m', price: 40, rating: 4.3, reviews: 520, seatsLeft: 28, premium: false, amenities: ['Life Jackets'] },
  { name: 'Elephanta Express', operator: 'Gateway Ferries', from: 'Gateway of India', to: 'Elephanta Island', departure: '10:00 AM', arrival: '10:55 AM', duration: '55m', price: 260, rating: 4.4, reviews: 980, seatsLeft: 22, premium: false, amenities: ['AC', 'Refreshments', 'Life Jackets'] },
  { name: 'Mumbai Ferry Express', operator: 'Mumbai Ferries', from: 'Mandwa', to: 'Mumbai', departure: '05:00 PM', arrival: '06:20 PM', duration: '1h 20m', price: 540, rating: 4.5, reviews: 700, seatsLeft: 20, premium: false, amenities: ['AC', 'WiFi', 'Life Jackets'] },
].map((f) => ({ ...f, blockedSeats: blocked }));

const routes = [
  { from: 'Mumbai', to: 'Alibaug', distance: '18 km', time: '8:00 AM' },
  { from: 'Mumbai', to: 'Mandwa', distance: '20 km', time: '7:00 AM' },
  { from: 'Port Blair', to: 'Havelock', distance: '54 km', time: '6:30 AM' },
  { from: 'Havelock', to: 'Neil Island', distance: '37 km', time: '9:00 AM' },
];

const active = [
  { name: 'Makruzz Gold', route: 'Port Blair → Havelock', progress: 65, location: '15 km from Port Blair', eta: '12 mins', speed: '28 km/h', passengers: 276, status: 'On Time' },
  { name: 'Sea Link Premium', route: 'Mumbai → Alibaug', progress: 82, location: 'Near Elephanta Island', eta: '8 mins', speed: '32 km/h', passengers: 115, status: 'On Time' },
  { name: 'Mumbai Ferry Express', route: 'Mandwa → Mumbai', progress: 100, location: 'Gateway of India', eta: 'Arrived', speed: '0 km/h', passengers: 142, status: 'Arrived' },
];

export async function seed() {
  await Promise.all([Ferry.deleteMany(), Route.deleteMany(), ActiveFerry.deleteMany()]);
  await Promise.all([Ferry.insertMany(ferries), Route.insertMany(routes), ActiveFerry.insertMany(active)]);
  console.log('Seeded ferries, routes and active ferries');
}

// `npm run seed` re-seeds the database from the command line
if (process.argv[1] && process.argv[1].endsWith('seed.js')) {
  const { connectDb } = await import('./db.js');
  await connectDb();
  await seed();
  process.exit(0);
}
