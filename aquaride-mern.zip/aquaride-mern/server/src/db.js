import mongoose from 'mongoose';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

// Uses MONGO_URI when set; otherwise starts a built-in MongoDB that saves to server/data
export async function connectDb() {
  let uri = process.env.MONGO_URI;
  if (!uri) {
    const { MongoMemoryServer } = await import('mongodb-memory-server');
    const dbPath = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data');
    fs.mkdirSync(dbPath, { recursive: true });
    const mongod = await MongoMemoryServer.create({ instance: { dbPath, port: 27018, storageEngine: 'wiredTiger' } });
    uri = mongod.getUri('aquaride');
    console.log('Using built-in database (first run downloads MongoDB once, please wait)');
  }
  await mongoose.connect(uri);
}
