import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import authRoutes from './routes/auth.js';
import ferryRoutes from './routes/ferries.js';
import bookingRoutes from './routes/bookings.js';
import trackingRoutes from './routes/tracking.js';
import Route from './models/Route.js';
import Ferry from './models/Ferry.js';
import { connectDb } from './db.js';
import { seed } from './seed.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.get('/api/routes', async (_req, res) => res.json(await Route.find().lean()));
app.use('/api/auth', authRoutes);
app.use('/api/ferries', ferryRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/tracking', trackingRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: 'Something went wrong on the server' });
});

const PORT = process.env.PORT || 5000;
connectDb()
  .then(async () => {
    if ((await Ferry.countDocuments()) === 0) await seed();
    app.listen(PORT, () => console.log(`AquaRide API running on http://localhost:${PORT}`));
  })
  .catch((e) => { console.error('Database connection failed:', e.message); process.exit(1); });
