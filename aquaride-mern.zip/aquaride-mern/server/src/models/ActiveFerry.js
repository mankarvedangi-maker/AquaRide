import mongoose from 'mongoose';
export default mongoose.model('ActiveFerry', new mongoose.Schema({
  name: String, route: String, progress: Number, location: String,
  eta: String, speed: String, passengers: Number, status: String,
}));
