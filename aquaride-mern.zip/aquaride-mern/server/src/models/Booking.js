import mongoose from 'mongoose';
export default mongoose.model('Booking', new mongoose.Schema({
  bookingId: { type: String, unique: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
  ferry: { type: mongoose.Schema.Types.ObjectId, ref: 'Ferry' },
  ferryName: String,
  route: String,
  date: String, // YYYY-MM-DD
  departure: String,
  seats: [String],
  passengers: Number,
  passenger: { name: String, email: String, phone: String },
  amount: { base: Number, gst: Number, fee: Number, total: Number },
  status: { type: String, enum: ['upcoming', 'completed', 'cancelled'], default: 'upcoming' },
}, { timestamps: true }));
