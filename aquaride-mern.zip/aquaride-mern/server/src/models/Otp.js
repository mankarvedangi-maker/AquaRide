import mongoose from 'mongoose';
const s = new mongoose.Schema({
  phone: { type: String, unique: true },
  code: String,
  createdAt: { type: Date, default: Date.now, expires: 300 },
});
export default mongoose.model('Otp', s);
