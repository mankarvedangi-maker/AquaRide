import mongoose from 'mongoose';
export default mongoose.model('User', new mongoose.Schema({
  phone: { type: String, unique: true, required: true },
  name: String,
  email: String,
}, { timestamps: true }));
