import mongoose from 'mongoose';
export default mongoose.model('Ferry', new mongoose.Schema({
  name: String,
  operator: String,
  from: String,
  to: String,
  departure: String,
  arrival: String,
  duration: String,
  price: Number,
  rating: Number,
  reviews: Number,
  seatsLeft: Number,
  premium: Boolean,
  amenities: [String],
  blockedSeats: [String], // always-unavailable seats on the 8x4 deck
}));
