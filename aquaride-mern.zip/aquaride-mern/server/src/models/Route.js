import mongoose from 'mongoose';
export default mongoose.model('Route', new mongoose.Schema({
  from: String, to: String, distance: String, time: String,
}));
