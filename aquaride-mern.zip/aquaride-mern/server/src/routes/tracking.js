import { Router } from 'express';
import ActiveFerry from '../models/ActiveFerry.js';
import Booking from '../models/Booking.js';

const r = Router();
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// ?q= a ferry name, or a booking ID (resolved to the ferry's name)
r.get('/', async (req, res) => {
  let q = (req.query.q || '').trim();
  if (q) {
    const b = await Booking.findOne({ bookingId: q.toUpperCase() }).lean();
    if (b) q = b.ferryName;
    return res.json(await ActiveFerry.find({ name: new RegExp(esc(q), 'i') }).lean());
  }
  res.json(await ActiveFerry.find().lean());
});

export default r;
