import { Router } from 'express';
import crypto from 'crypto';
import requireAuth from '../middleware/auth.js';
import Booking from '../models/Booking.js';
import Ferry from '../models/Ferry.js';

const r = Router();
r.use(requireAuth);

const today = () => new Date().toISOString().slice(0, 10);

r.get('/', async (req, res) => {
  const list = await Booking.find({ user: req.userId }).sort({ createdAt: -1 }).lean();
  // upcoming bookings whose date has passed are shown as completed
  res.json(list.map((b) => (b.status === 'upcoming' && b.date < today() ? { ...b, status: 'completed' } : b)));
});

r.post('/', async (req, res) => {
  const { ferryId, date, seats, passenger } = req.body;
  if (!Array.isArray(seats) || !seats.length) return res.status(400).json({ message: 'Select at least one seat' });
  if (!passenger?.name || !passenger?.email || !passenger?.phone) return res.status(400).json({ message: 'Please fill in all passenger details' });
  if (!date || date < today()) return res.status(400).json({ message: 'Choose a journey date that is today or later' });

  const ferry = await Ferry.findById(ferryId).catch(() => null);
  if (!ferry) return res.status(404).json({ message: 'Ferry not found' });

  const taken = await Booking.find({ ferry: ferry._id, date, status: { $ne: 'cancelled' }, seats: { $in: seats } }).lean();
  const clash = seats.filter((s) => ferry.blockedSeats.includes(s) || taken.some((b) => b.seats.includes(s)));
  if (clash.length) return res.status(409).json({ message: `Seat ${clash.join(', ')} was just taken. Pick another seat.` });

  const base = ferry.price * seats.length;
  const gst = Math.round(base * 0.05 * 100) / 100;
  const fee = 50;
  const booking = await Booking.create({
    bookingId: 'AQ' + crypto.randomBytes(3).toString('hex').toUpperCase(),
    user: req.userId,
    ferry: ferry._id,
    ferryName: ferry.name,
    route: `${ferry.from} → ${ferry.to}`,
    date,
    departure: ferry.departure,
    seats,
    passengers: seats.length,
    passenger,
    amount: { base, gst, fee, total: base + gst + fee },
  });
  await Ferry.updateOne({ _id: ferry._id }, { $inc: { seatsLeft: -seats.length } });
  res.status(201).json(booking);
});

r.patch('/:bookingId/cancel', async (req, res) => {
  const b = await Booking.findOne({ bookingId: req.params.bookingId, user: req.userId });
  if (!b) return res.status(404).json({ message: 'Booking not found' });
  if (b.status !== 'upcoming') return res.status(400).json({ message: 'Only upcoming bookings can be cancelled' });
  b.status = 'cancelled';
  await b.save();
  await Ferry.updateOne({ _id: b.ferry }, { $inc: { seatsLeft: b.seats.length } });
  res.json(b);
});

export default r;
