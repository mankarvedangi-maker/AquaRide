import { Router } from 'express';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import User from '../models/User.js';
import Otp from '../models/Otp.js';

const r = Router();
const isProd = process.env.NODE_ENV === 'production';

r.post('/send-otp', async (req, res) => {
  const { phone } = req.body;
  if (!/^\d{10}$/.test(phone || '')) return res.status(400).json({ message: 'Enter a valid 10-digit phone number' });
  const code = String(crypto.randomInt(100000, 1000000));
  await Otp.findOneAndUpdate({ phone }, { code, createdAt: new Date() }, { upsert: true });
  // TODO: plug in an SMS provider (Twilio, MSG91...) here.
  console.log(`OTP for ${phone}: ${code}`);
  res.json({ sent: true, ...(isProd ? {} : { devOtp: code }) });
});

r.post('/verify', async (req, res) => {
  const { phone, otp } = req.body;
  const rec = await Otp.findOne({ phone });
  if (!rec || rec.code !== otp) return res.status(400).json({ message: 'That code is incorrect or has expired' });
  await rec.deleteOne();
  const user = await User.findOneAndUpdate({ phone }, { phone }, { upsert: true, new: true });
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'dev-secret', { expiresIn: '7d' });
  res.json({ token, user: { id: user._id, phone: user.phone, name: user.name } });
});

export default r;
