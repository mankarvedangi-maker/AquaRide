import { Router } from 'express';
import Ferry from '../models/Ferry.js';
import Booking from '../models/Booking.js';

const r = Router();

r.get('/', async (req, res) => {
  const { from, to } = req.query;
  const q = {};
  if (from) q.from = from;
  if (to) q.to = to;
  res.json(await Ferry.find(q).lean());
});

r.get('/:id', async (req, res) => {
  const ferry = await Ferry.findById(req.params.id).lean().catch(() => null);
  if (!ferry) return res.status(404).json({ message: 'Ferry not found' });
  res.json(ferry);
});

// Seats that can't be picked on a given date: blocked on the deck + already booked
r.get('/:id/seats', async (req, res) => {
  const ferry = await Ferry.findById(req.params.id).lean().catch(() => null);
  if (!ferry) return res.status(404).json({ message: 'Ferry not found' });
  const booked = await Booking.find({ ferry: ferry._id, date: req.query.date, status: { $ne: 'cancelled' } }).lean();
  const unavailable = [...new Set([...ferry.blockedSeats, ...booked.flatMap((b) => b.seats)])];
  res.json({ ferry, unavailable });
});

export default r;
