const BASE = import.meta.env.VITE_API_URL || '/api';

export async function api(path, { method = 'GET', body } = {}) {
  const token = localStorage.getItem('aq_token');
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
}

export const fmtDate = (iso) => new Date(iso + 'T00:00').toLocaleDateString('en-US');
export const todayISO = () => new Date().toISOString().slice(0, 10);
export const PLACES = ['Mumbai', 'Alibaug', 'Mandwa', 'Port Blair', 'Havelock', 'Neil Island', 'Goa (Panaji)', 'Divar Island', 'Kochi', 'Vypeen', 'Elephanta Island', 'Gateway of India'];
