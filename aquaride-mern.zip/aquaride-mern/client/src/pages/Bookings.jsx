import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, fmtDate } from '../api.js';
import { useToast } from '../ui.jsx';
import Nav from '../components/Nav.jsx';
import Icon from '../components/Icon.jsx';

const TABS = [['upcoming', 'Upcoming', 'clock'], ['completed', 'Completed', 'ccheck'], ['cancelled', 'Cancelled', 'x']];
const LABEL = { upcoming: 'CONFIRMED', completed: 'COMPLETED', cancelled: 'CANCELLED' };

export default function Bookings() {
  const nav = useNavigate();
  const toast = useToast();
  const [list, setList] = useState([]);
  const [tab, setTab] = useState('upcoming');
  const load = () => api('/bookings').then(setList).catch((e) => toast(e.message));
  useEffect(() => { load(); }, []);

  async function cancel(id) {
    try { await api(`/bookings/${id}/cancel`, { method: 'PATCH' }); toast('Booking cancelled'); setTab('cancelled'); load(); }
    catch (e) { toast(e.message); }
  }
  const shown = list.filter((b) => b.status === tab);
  const upcoming = list.filter((b) => b.status === 'upcoming').length;

  return (
    <>
      <Nav on="bk" />
      <div className="pg">
        <div className="narrow">
          <div className="pt"><h1>My Bookings</h1><p style={{ marginBottom: 0 }}>Manage and track all your ferry bookings</p></div>
          <div className="tabs">
            {TABS.map(([k, t, ic]) => (
              <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>
                <Icon n={ic} s={13} /> {t}{k === 'upcoming' && <em>{upcoming}</em>}
              </button>
            ))}
          </div>
          {shown.length ? shown.map((b) => (
            <div className="card bkc" key={b.bookingId}>
              <div className="m">
                <div className="row sp">
                  <div>
                    <h3 className="row gap" style={{ fontSize: 15, fontWeight: 600, color: 'var(--ink)' }}>
                      <span style={{ color: b.status === 'upcoming' ? '#16a34a' : b.status === 'cancelled' ? '#dc2626' : '#2563eb' }}><Icon n={b.status === 'cancelled' ? 'x' : 'ccheck'} s={16} /></span>{b.ferryName}
                    </h3>
                    <small style={{ color: 'var(--mut)', fontSize: 12, marginLeft: 24 }}>Booking ID: {b.bookingId}</small>
                  </div>
                  <span className={`st ${b.status === 'completed' ? 'c' : ''}`} style={b.status === 'cancelled' ? { background: '#fee2e2', color: '#dc2626' } : undefined}>{LABEL[b.status]}</span>
                </div>
                <div className="g">
                  <div><Icon n="pin" s={15} /><span>Route<b>{b.route}</b></span></div>
                  <div><Icon n="cal" s={15} /><span>Journey Date<b>{fmtDate(b.date)} • {b.departure}</b></span></div>
                  <div><Icon n="users" s={15} /><span>Passengers<b>{b.passengers} Adult(s) · {b.seats.join(', ')}</b></span></div>
                  <div><Icon n="tix" s={15} /><span>Total Paid<b className="pa">₹{b.amount.total}</b></span></div>
                </div>
                {b.status === 'upcoming' && <div className="tl" style={{ borderTop: '1px solid var(--line)', paddingTop: 12 }} onClick={() => nav('/track')}>Track this ferry in real-time →</div>}
              </div>
              <div className="acts">
                <button onClick={() => toast('QR ticket coming soon')}><Icon n="qr" s={13} /> QR Code</button>
                <button onClick={() => toast('Ticket download coming soon')}><Icon n="dl" s={13} /> Download</button>
                {b.status === 'upcoming' && <button className="cn" onClick={() => cancel(b.bookingId)}>Cancel</button>}
              </div>
            </div>
          )) : (
            <div className="card emp"><Icon n="ccheck" /><div>No {tab} bookings</div></div>
          )}
          <div className="help">
            <h3>Need Help?</h3>
            <p>Have questions about your booking? Our support team is here to help 24/7.</p>
            <button onClick={() => toast('Support will contact you shortly')}>Contact Support</button>
            <button onClick={() => toast('FAQs coming soon')}>View FAQs</button>
          </div>
        </div>
      </div>
    </>
  );
}
