import { useEffect, useState } from 'react';
import { api } from '../api.js';
import Nav from '../components/Nav.jsx';
import Icon from '../components/Icon.jsx';

export default function Track() {
  const [q, setQ] = useState('');
  const [ferries, setFerries] = useState([]);
  const [msg, setMsg] = useState('');
  const load = (term = '') => api(`/tracking?q=${encodeURIComponent(term)}`).then((d) => { setFerries(d); setMsg(d.length ? '' : 'No active ferry found for that ID.'); }).catch((e) => setMsg(e.message));
  useEffect(() => { load(); }, []);
  const lead = ferries[0];

  return (
    <>
      <Nav on="track" />
      <div className="pg">
        <div className="pt" style={{ maxWidth: 1100, margin: '0 auto' }}>
          <h1>Live Ferry Tracking</h1>
          <p style={{ marginBottom: 0 }}>Track your ferry in real-time, just like Uber</p>
        </div>
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>
          <div className="card tsr">
            <div className="fld"><input placeholder="Enter Booking ID or Ferry Number" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load(q)} /></div>
            <button className="tb" onClick={() => load(q)}><Icon n="nav" s={14} /> Track Ferry</button>
          </div>
          <div className="tr">
            <div className="map">
              <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} viewBox="0 0 100 100" preserveAspectRatio="none">
                <line x1="12" y1="18" x2="78" y2="32" stroke="#60a5fa" strokeDasharray="2 2" vectorEffect="non-scaling-stroke" style={{ strokeWidth: 1.5 }} />
              </svg>
              <div className="pt2" style={{ left: '8%', top: '12%' }}><i style={{ background: '#2563eb' }}><Icon n="anchor" s={14} /></i><span>Port Blair</span></div>
              <div className="pt2" style={{ left: '40%', top: '20%' }}><i style={{ background: '#f97316', width: 30, height: 30 }}><Icon n="bolt" s={15} /></i><span>{lead ? lead.name : 'Makruzz Gold'}<br />{lead ? lead.speed : '28 km/h'}</span></div>
              <div className="pt2" style={{ left: '77%', top: '30%' }}><i style={{ background: '#16a34a' }}><Icon n="anchor" s={14} /></i><span>Havelock</span></div>
              <div className="mc">
                <span style={{ color: '#2563eb' }}><Icon n="pin" s={44} /></span>
                <b>Live Map View</b><small>Real-time ferry positions displayed here</small>
              </div>
            </div>
            <div className="af">
              <h3>Active Ferries</h3>
              {msg && <div className="card c">{msg}</div>}
              {ferries.map((a) => (
                <div className="card c" key={a._id}>
                  <div className="h">
                    <b>{a.name}</b>
                    <span className="gb" style={a.status === 'Arrived' ? { background: '#dbeafe', color: '#2563eb' } : undefined}>{a.status}</span>
                  </div>
                  <div>{a.route}</div>
                  <div className="bar2"><i style={{ width: `${a.progress}%` }} /></div>
                  <div className="i"><span><Icon n="pin" s={13} /> {a.location}</span></div>
                  <div className="i"><span><Icon n="clock" s={13} /> ETA: {a.eta}</span><span><Icon n="nav" s={13} /> {a.speed}</span></div>
                  <div className="i"><span><Icon n="users" s={13} /> {a.passengers} passengers</span></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
