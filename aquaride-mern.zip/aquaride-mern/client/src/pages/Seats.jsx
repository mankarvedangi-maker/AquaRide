import { useEffect, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { api, todayISO } from '../api.js';
import Icon from '../components/Icon.jsx';

const ROWS = 'ABCDEFGH'.split('');

export default function Seats() {
  const { id } = useParams();
  const [sp] = useSearchParams();
  const date = sp.get('date') || todayISO();
  const nav = useNavigate();
  const [data, setData] = useState(null);
  const [sel, setSel] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api(`/ferries/${id}/seats?date=${date}`).then(setData).catch((e) => setError(e.message));
  }, [id, date]);

  if (error) return <div className="pg"><div className="card emp">{error}</div></div>;
  if (!data) return null;
  const { ferry, unavailable } = data;
  const toggle = (s) => setSel((p) => (p.includes(s) ? p.filter((x) => x !== s) : [...p, s]));

  return (
    <>
      <div className="sh">
        <button className="bkb" onClick={() => nav(-1)}><Icon n="back" s={18} /></button>
        <div><h3>{ferry.name}</h3><small>{ferry.from} → {ferry.to}</small></div>
        <span className="lf">{ferry.seatsLeft} seats left</span>
      </div>
      <div className="deck"><span>● Main Deck</span></div>
      <div className="hull">
        <div className="bow">Front (Bow)</div>
        <div className="grid">
          {ROWS.map((r) => (
            <div key={r} style={{ display: 'contents' }}>
              <div className="rl">{r}</div>
              {[1, 2, 3, 4].map((c) => {
                const s = r + c;
                const sold = unavailable.includes(s);
                return (
                  <button key={s} disabled={sold} onClick={() => toggle(s)}
                    className={`seat ${sold ? 'sold' : ''} ${sel.includes(s) ? 'on' : ''}`} aria-label={`Seat ${s}`}>
                    <Icon n="sofa" s={16} />
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>
      <div style={{ height: 90 }} />
      <div className="bar">
        <div><small>{sel.length} seats selected</small><b>₹{sel.length * ferry.price}</b></div>
        <button disabled={!sel.length} onClick={() => nav(`/ferry/${id}/book?date=${date}`, { state: { seats: sel } })}>Continue to Payment</button>
      </div>
    </>
  );
}
