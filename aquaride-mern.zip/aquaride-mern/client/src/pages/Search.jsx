import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api, fmtDate, PLACES, todayISO } from '../api.js';
import Nav from '../components/Nav.jsx';
import Icon from '../components/Icon.jsx';

const amIcon = (a) => (a === 'WiFi' ? 'wifi' : a === 'AC' ? 'wave' : 'cup');

export default function Search() {
  const nav = useNavigate();
  const [sp, setSp] = useSearchParams();
  const from = sp.get('from') || '';
  const to = sp.get('to') || '';
  const date = sp.get('date') || '';
  const [f, setF] = useState(from);
  const [t, setT] = useState(to);
  const [d, setD] = useState(date);
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { setF(from); setT(to); setD(date); }, [from, to, date]);
  useEffect(() => {
    setLoading(true);
    api(`/ferries?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`)
      .then(setList).catch(() => setList([])).finally(() => setLoading(false));
  }, [from, to]);

  const searched = from && to;
  const submit = () => { if (f && t) setSp({ from: f, to: t, ...(d ? { date: d } : {}) }); };
  const pick = (id) => nav(`/ferry/${id}/seats?date=${date || todayISO()}`);
  const select = (ph, val, set) => (
    <div className="fld">
      <select style={{ width: '100%' }} value={val} onChange={(e) => set(e.target.value)}>
        <option value="">{ph}</option>
        {PLACES.map((p) => <option key={p}>{p}</option>)}
      </select>
      <Icon n="down" s={14} />
    </div>
  );

  return (
    <>
      <Nav on="search" />
      <div className="pg">
        <div className="fl">
          <div><label><Icon n="pin" s={15} /> From</label>{select('Select origin', f, setF)}</div>
          <div><label><Icon n="pin" s={15} /> To</label>{select('Select destination', t, setT)}</div>
          <div><label><Icon n="cal" s={15} /> Journey Date</label>
            <div className="fld" style={{ background: '#fff', border: '1px solid var(--line)' }}>
              <input type="date" min={todayISO()} value={d} onChange={(e) => setD(e.target.value)} />
            </div>
          </div>
        </div>
        <button className="btn sbtn" disabled={!f || !t} onClick={submit}>Search Ferries <Icon n="arr" s={15} /></button>

        <div className="row sp" style={{ margin: '0 0 14px' }}>
          <div>
            {searched ? (
              <>
                <h2 style={{ fontSize: 23 }}>{from} → {to}</h2>
                <span style={{ color: 'var(--mut)' }}>{list.length} ferries available{date ? ` on ${fmtDate(date)}` : ''}</span>
              </>
            ) : (
              <>
                <div style={{ fontSize: 18 }}>→</div>
                <span style={{ color: 'var(--mut)' }}>{list.length} ferries available</span>
              </>
            )}
          </div>
          <button className="flt"><Icon n="filt" s={16} /> Filters</button>
        </div>

        <div className="res">
          <div>
            <div className="ai">
              <h4><Icon n="spark" s={18} /> AI Smart Insights</h4>
              <li>• Low crowd expected today. Book premium for best experience.</li>
              <li>• Prices 15% lower than usual for afternoon slots</li>
            </div>
            {!loading && !list.length && <div className="card emp">No ferries found for this route.</div>}
            {list.map((x) => (
              <div className="card fc" key={x._id}>
                <div className="m">
                  <div className="t">
                    <div><h3>{x.name}</h3><span style={{ color: 'var(--mut)', fontSize: 13 }}>{x.operator}</span></div>
                    {x.premium && <span className="badge">PREMIUM</span>}
                  </div>
                  <div className="tm">
                    <div><b>{x.departure}</b><span>{x.from}</span></div>
                    <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}><Icon n="clock" s={13} /> {x.duration}</span>
                    <div style={{ textAlign: 'right' }}><b>{x.arrival}</b><span>{x.to}</span></div>
                  </div>
                  <div className="am">
                    {x.amenities.slice(0, 3).map((a) => <span key={a}><Icon n={amIcon(a)} s={11} /> {a}</span>)}
                    {x.amenities.length > 3 && <span style={{ background: 'none', color: 'var(--mut)' }}>+{x.amenities.length - 3} more</span>}
                  </div>
                  <div className="row gap" style={{ fontSize: 13 }}>
                    <Icon n="star" s={14} /><b style={{ fontWeight: 500 }}>{x.rating}</b><span style={{ color: 'var(--mut)' }}>({x.reviews})</span>
                    &nbsp;<span style={{ color: '#ea580c', display: 'flex', gap: 6, alignItems: 'center' }}><Icon n="users" s={14} /> {x.seatsLeft} seats left</span>
                  </div>
                </div>
                <div className="pr">
                  <span className="bp">↘ Best Price</span><b>₹{x.price}</b><small>per person</small>
                  <button className="sel" onClick={() => pick(x._id)}>Select Seats</button>
                </div>
              </div>
            ))}
          </div>
          <div className="side">
            {searched && (
              <div className="card wx">
                <h3 className="row gap" style={{ color: 'var(--p)' }}><Icon n="cloud" s={16} /> <span style={{ color: 'var(--ink)' }}>Weather Conditions</span></h3>
                <div className="r"><span>Condition</span><span className="gb">Clear Sky</span></div>
                <div className="r"><span>Temperature</span><b>32°C</b></div>
                <div className="r"><span>Wind Speed</span><b>8 km/h</b></div>
                <div className="r"><span>Wave Height</span><b>0.8m</b></div>
                <div className="r"><span>Visibility</span><b>Excellent</b></div>
                <div className="ok">✓ Safe for sailing</div>
              </div>
            )}
            <div className="card">
              <h3>Travel Tips</h3>
              <ul style={{ padding: 0 }}>
                <li>Arrive 30 minutes before departure</li><li>Carry valid ID proof for verification</li>
                <li>Check weather updates before travel</li><li>Digital tickets accepted on all ferries</li>
              </ul>
            </div>
            <div className="card mm">
              <h3>Multi-Modal Travel</h3>
              <p style={{ fontSize: 13, color: '#475569' }}>Combine ferry with train or cab for complete journey planning</p>
              <button>Explore Options</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
