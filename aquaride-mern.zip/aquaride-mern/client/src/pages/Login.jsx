import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';
import { useToast } from '../ui.jsx';
import Icon from '../components/Icon.jsx';

export default function Login() {
  const [step, setStep] = useState('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [devOtp, setDevOtp] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const { login } = useAuth();
  const nav = useNavigate();
  const toast = useToast();

  async function sendOtp() {
    setBusy(true); setError('');
    try {
      const d = await api('/auth/send-otp', { method: 'POST', body: { phone } });
      setDevOtp(d.devOtp || ''); setOtp(''); setStep('otp');
    } catch (e) { setError(e.message); }
    setBusy(false);
  }
  async function verify() {
    setBusy(true); setError('');
    try {
      const d = await api('/auth/verify', { method: 'POST', body: { phone, otp } });
      login(d.token); nav('/home', { replace: true });
    } catch (e) { setError(e.message); }
    setBusy(false);
  }
  const digits = (setter, max) => (e) => setter(e.target.value.replace(/\D/g, '').slice(0, max));

  return (
    <div id="auth">
      <div className="ico"><Icon n="ship" s={26} /></div>
      <h1>Welcome to AquaRide</h1>
      <p className="sub">India’s Marine Travel Platform</p>
      <div className="card box">
        {step === 'phone' ? (
          <>
            <label className="l">Phone Number</label>
            <div className="inp"><Icon n="phone" s={18} /><input inputMode="numeric" placeholder="Enter 10-digit number" value={phone} onChange={digits(setPhone, 10)} autoFocus /></div>
            <p className="hint">We’ll send you a verification code</p>
            {error && <p className="err">{error}</p>}
            <button className="btn" disabled={phone.length !== 10 || busy} onClick={sendOtp}>Send OTP <Icon n="arr" s={15} /></button>
            <div className="or">or continue with</div>
            <button className="gbtn" onClick={() => toast('Google sign-in is not set up yet')}><Icon n="ccheck" s={16} /> Continue with Google</button>
          </>
        ) : (
          <>
            <div className="otpi"><Icon n="phone" s={22} /></div>
            <h3 style={{ textAlign: 'center', fontSize: 16 }}>Verify OTP</h3>
            <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--mut)', margin: '8px 0 22px' }}>
              Code sent to +91 {phone}{' '}
              <a style={{ color: 'var(--p)', fontWeight: 600, cursor: 'pointer' }} onClick={() => setStep('phone')}>Change</a>
            </p>
            <label className="l" style={{ fontSize: 12 }}>Enter 6-digit OTP</label>
            <div className="inp"><input id="otp" inputMode="numeric" placeholder="000000" value={otp} onChange={digits(setOtp, 6)} autoFocus /></div>
            {devOtp && <p className="devotp" style={{ marginTop: 10 }}>Dev mode OTP: {devOtp}</p>}
            {error && <p className="err" style={{ marginTop: 10 }}>{error}</p>}
            <button className="btn" style={{ margin: '18px 0 14px' }} disabled={otp.length !== 6 || busy} onClick={verify}>Verify &amp; Continue <Icon n="arr" s={15} /></button>
            <p style={{ textAlign: 'center', fontSize: 12, color: '#475569', cursor: 'pointer' }} onClick={sendOtp}>Didn’t receive code? Resend</p>
          </>
        )}
      </div>
      <p className="legal">By continuing, you agree to AquaRide’s Terms &amp; Privacy Policy</p>
      <div className="waves" />
    </div>
  );
}
