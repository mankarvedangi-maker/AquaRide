import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import Icon from '../components/Icon.jsx';

export default function Splash() {
  const nav = useNavigate();
  const { token } = useAuth();
  useEffect(() => {
    const t = setTimeout(() => nav(token ? '/home' : '/login', { replace: true }), 2200);
    return () => clearTimeout(t);
  }, [nav, token]);
  return (
    <div id="splash">
      <div className="lg"><Icon n="ship" s={44} /></div>
      <h1>AquaRide</h1>
      <p>Ride the Waves, Seamlessly</p>
      <div className="dots"><i /><i /><i /></div>
    </div>
  );
}
