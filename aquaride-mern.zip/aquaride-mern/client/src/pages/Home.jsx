import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';
import Icon from '../components/Icon.jsx';

const ACTIONS = [
  ['Book Ferry', 'ship', 'linear-gradient(135deg,#0a7fb5,#12bfd6)', '/search'],
  ['Track Ride', 'nav', 'linear-gradient(135deg,#0ea5c9,#22d3ee)', '/track'],
  ['My Tickets', 'tix', 'linear-gradient(135deg,#f4606f,#f68a58)', '/bookings'],
  ['Offers', 'pct', 'linear-gradient(135deg,#10b981,#059669)', '/search'],
];

export default function Home() {
  const nav = useNavigate();
  const { logout } = useAuth();
  const [routes, setRoutes] = useState([]);
  useEffect(() => { api('/routes').then(setRoutes).catch(() => {}); }, []);
  const toRoute = (r) => nav(`/search?from=${encodeURIComponent(r.from)}&to=${encodeURIComponent(r.to)}`);

  return (
    <>
      <div className="hhead">
        <div className="row sp">
          <div className="row gap">
            <div className="hlogo"><Icon n="ship" s={16} /></div>
            <div><b className="pop" style={{ fontSize: 17 }}>AquaRide</b><div style={{ fontSize: 10, opacity: 0.85 }}>Ride the Waves</div></div>
          </div>
          <div className="row">
            <div className="circ"><Icon n="bell" s={14} /></div>
            <div className="circ" style={{ cursor: 'pointer' }} title="Sign out" onClick={() => { logout(); nav('/login'); }}><Icon n="user" s={14} /></div>
          </div>
        </div>
        <button className="sbar" onClick={() => nav('/search')}>
          <span className="ic"><Icon n="search" s={16} /></span>
          <span>
            <b className="pop" style={{ fontSize: 14, display: 'block', fontWeight: 500 }}>Where do you want to go?</b>
            <span style={{ fontSize: 12, color: 'var(--mut)' }}>Search routes, ferries &amp; more</span>
          </span>
        </button>
      </div>
      <div className="wrap">
        <div className="qa">
          {ACTIONS.map(([t, ic, bg, to]) => (
            <button key={t} onClick={() => nav(to)}><i style={{ background: bg }}><Icon n={ic} s={18} /></i>{t}</button>
          ))}
        </div>
        <div className="offer">
          <div>
            <span className="tg"><Icon n="bolt" s={11} /> Limited Offer</span>
            <h3>20% OFF on Goa Ferries</h3>
            <p>Valid for bookings this week</p>
            <button className="w" onClick={() => nav('/search?from=Goa%20(Panaji)&to=Divar%20Island')}>Book Now</button>
          </div>
          <div className="ib"><Icon n="tag" s={26} /></div>
        </div>
        <div className="sec"><h2>Popular Routes</h2><a onClick={() => nav('/search')}>View All</a></div>
        {routes.map((r) => (
          <div key={r._id} className="card rt" onClick={() => toRoute(r)}>
            <div className="ic"><Icon n="ship" s={16} /></div>
            <div>
              <b>{r.from} <span style={{ color: 'var(--mut)' }}><Icon n="pin" s={13} /></span> {r.to}</b>
              <small>{r.distance} &nbsp;•&nbsp; <Icon n="clock" s={10} /> {r.time}</small>
            </div>
            <span className="pill"><Icon n="trend" s={11} /> Popular</span>
          </div>
        ))}
      </div>
    </>
  );
}
