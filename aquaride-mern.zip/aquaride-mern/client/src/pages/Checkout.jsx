import { useEffect, useState } from 'react';
import { Navigate, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { api, todayISO } from '../api.js';
import { useToast } from '../ui.jsx';
import Nav from '../components/Nav.jsx';
import Icon from '../components/Icon.jsx';

export default function Checkout() {
  const { id } = useParams();
  const [sp] = useSearchParams();
  const date = sp.get('date') || todayISO();
  const seats = useLocation().state?.seats;
  const nav = useNavigate();
  const toast = useToast();
  const [ferry, setFerry] = useState(null);
  const [form, setForm] = useState({ name: '', email: '', phone: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => { api(`/ferries/${id}`).then(setFerry).catch((e) => setError(e.message)); }, [id]);

  if (!seats?.length) return <Navigate to={`/ferry/${id}/seats?date=${date}`} replace />;
  if (!ferry) return <><Nav on="search" />{error && <div className="pg"><div className="card emp">{error}</div></div>}</>;

  const base = ferry.price * seats.length;
  const gst = Math.round(base * 0.05 * 100) / 100;
  const total = base + gst + 50;
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function pay() {
    setBusy(true); setError('');
    try {
      await api('/bookings', { method: 'POST', body: { ferryId: id, date, seats, passenger: form } });
      toast('Booking confirmed!');
      nav('/bookings');
    } catch (e) { setError(e.message); }
    setBusy(false);
  }

  return (
    <>
      <Nav on="search" />
      <div className="pg">
        <div className="narrow" style={{ maxWidth: 940 }}>
          <div className="pt"><h1>Complete Your Booking</h1><p>Review details and enter passenger information</p></div>
          <div className="bg">
            <div>
              <div className="card bx">
                <div className="row sp"><h3 style={{ fontSize: 17, margin: 0 }}>{ferry.name}</h3>{ferry.premium && <span className="badge">PREMIUM</span>}</div>
                <span style={{ color: 'var(--mut)', fontSize: 13 }}>{ferry.operator}</span>
                <div className="dg">
                  <div><Icon n="pin" s={16} /><div><small>From</small><b>{ferry.from}</b></div></div>
                  <div><Icon n="pin" s={16} /><div><small>To</small><b>{ferry.to}</b></div></div>
                  <div><Icon n="clock" s={16} /><div><small>Departure</small><b>{ferry.departure}</b></div></div>
                  <div><Icon n="clock" s={16} /><div><small>Duration</small><b>{ferry.duration}</b></div></div>
                </div>
                <div className="row gap" style={{ fontSize: 12 }}><Icon n="star" s={13} /> {ferry.rating} &nbsp;•&nbsp; {ferry.amenities.join(', ')}</div>
              </div>
              <div className="card bx">
                <h3>Passenger Information</h3>
                <small style={{ fontWeight: 500, fontSize: 13 }}>Number of Passengers</small>
                <div className="cnt">
                  <button disabled title="Change by selecting seats">-</button>
                  <span><Icon n="users" s={14} /> {seats.length}</span>
                  <button disabled title="Change by selecting seats">+</button>
                  <small style={{ color: 'var(--mut)' }}>Seats {seats.join(', ')}</small>
                </div>
                <label className="l" style={{ fontSize: 13 }}><Icon n="user" s={14} /> Full Name *</label>
                <div className="fld"><input placeholder="Enter your full name" value={form.name} onChange={set('name')} /></div>
                <label className="l" style={{ fontSize: 13 }}>Email Address *</label>
                <div className="fld"><input type="email" placeholder="your.email@example.com" value={form.email} onChange={set('email')} /></div>
                <label className="l" style={{ fontSize: 13 }}>Phone Number *</label>
                <div className="fld"><input placeholder="+91 XXXXX XXXXX" value={form.phone} onChange={set('phone')} /></div>
                <h3 className="row gap" style={{ marginTop: 22 }}><Icon n="card" s={16} /> Payment Method</h3>
                <div className="pay">
                  <i><Icon n="card" s={16} /></i>
                  <div><b style={{ fontWeight: 500 }}>UPI / Cards / Net Banking</b><small>Secure payment via Razorpay</small></div>
                  <span className="ck"><Icon n="chk" s={16} /></span>
                </div>
                {error && <p className="err" style={{ margin: '0 0 12px' }}>{error}</p>}
                <button className="btn" style={{ background: '#0a7fb5' }} disabled={busy || !form.name || !form.email || !form.phone} onClick={pay}>
                  Proceed to Payment - ₹{total.toFixed(2)}
                </button>
              </div>
            </div>
            <div className="card bx ps">
              <h3 style={{ fontSize: 15 }}>Price Summary</h3>
              <div className="r"><span>Base Fare ({seats.length} × ₹{ferry.price})</span><span>₹{base}</span></div>
              <div className="r"><span>GST (5%)</span><span>₹{gst.toFixed(2)}</span></div>
              <div className="r"><span>Convenience Fee</span><span>₹50</span></div>
              <div className="r tot"><span>Total Amount</span><b>₹{total.toFixed(2)}</b></div>
              <ul style={{ padding: 0, marginTop: 14 }}>
                <li><Icon n="shield" s={13} /> Secure payment with 256-bit SSL encryption</li>
                <li><Icon n="chk" s={13} /> Instant digital ticket via email &amp; SMS</li>
                <li><Icon n="chk" s={13} /> Free cancellation up to 24 hours before</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
