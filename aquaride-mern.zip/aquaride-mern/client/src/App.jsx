import { Navigate, Route, Routes } from 'react-router-dom';
import { Private } from './auth.jsx';
import Splash from './pages/Splash.jsx';
import Login from './pages/Login.jsx';
import Home from './pages/Home.jsx';
import Search from './pages/Search.jsx';
import Seats from './pages/Seats.jsx';
import Checkout from './pages/Checkout.jsx';
import Bookings from './pages/Bookings.jsx';
import Track from './pages/Track.jsx';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Splash />} />
      <Route path="/login" element={<Login />} />
      <Route path="/home" element={<Private><Home /></Private>} />
      <Route path="/search" element={<Private><Search /></Private>} />
      <Route path="/ferry/:id/seats" element={<Private><Seats /></Private>} />
      <Route path="/ferry/:id/book" element={<Private><Checkout /></Private>} />
      <Route path="/bookings" element={<Private><Bookings /></Private>} />
      <Route path="/track" element={<Private><Track /></Private>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
