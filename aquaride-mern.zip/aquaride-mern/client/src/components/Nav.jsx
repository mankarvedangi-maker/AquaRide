import { Link } from 'react-router-dom';
import Icon from './Icon.jsx';

export default function Nav({ on }) {
  const l = (k, t, to) => <Link key={k} to={to} className={on === k ? 'on' : ''}>{t}</Link>;
  return (
    <nav>
      <Link to="/home" className="brand"><i><Icon n="wave" s={18} /></i>AquaRide</Link>
      <div className="links">
        {l('home', 'Home', '/home')}{l('search', 'Search', '/search')}{l('track', 'Live Tracking', '/track')}{l('bk', 'My Bookings', '/bookings')}
      </div>
      <div className="nr">
        <Link to="/track" className="tf row gap"><Icon n="map" s={16} /> Track Ferry</Link>
        <Link to="/bookings" className="tk"><Icon n="tix" s={16} /> My Tickets</Link>
      </div>
    </nav>
  );
}
