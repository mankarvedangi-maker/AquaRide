import { createContext, useContext, useState } from 'react';
import { Navigate } from 'react-router-dom';

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('aq_token'));
  const login = (t) => { localStorage.setItem('aq_token', t); setToken(t); };
  const logout = () => { localStorage.removeItem('aq_token'); setToken(null); };
  return <AuthCtx.Provider value={{ token, login, logout }}>{children}</AuthCtx.Provider>;
}

export function Private({ children }) {
  const { token } = useAuth();
  return token ? children : <Navigate to="/login" replace />;
}
